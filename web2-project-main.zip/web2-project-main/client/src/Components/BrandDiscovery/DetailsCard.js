import React from 'react'
import './DetailsCard.css'
import SearchBrand from './SearchBrand'



const DetailsCard = () => {
  
  
  return (
    

    <>
       <div className='brand-cards'>
        <SearchBrand/>
       </div>
    </>
  )  
}

export default DetailsCard
