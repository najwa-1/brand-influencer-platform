
import Banner from './Banner';
import Collaborate from './Collaborate';
import ChoosePlatform from './ChoosePlatform';
import CollaborationSteps from './CollaborationSteps';
import UpgradeCard from './UpgradeCard';
import Finalone from './Finalone';



function Allbusiness() {
  return (
    <>
     
      <Banner />
     <Collaborate/>
      <ChoosePlatform/>
     <CollaborationSteps/>
     <UpgradeCard/>
     <Finalone/>


    </>
  );
}

export default Allbusiness;
