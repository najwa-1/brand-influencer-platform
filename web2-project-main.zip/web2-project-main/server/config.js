
const PORT=4000;
const mongoDBURL="mongodb+srv://s12116485:tX9k6q7E2Nf2KJn@cluster0.5r71wo6.mongodb.net/web2-project?retryWrites=true&w=majority&appName=Cluster0";
module.exports={PORT,mongoDBURL}